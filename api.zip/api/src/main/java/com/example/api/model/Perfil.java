package com.example.api.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "perfiles")
public class Perfil extends Usuario {

    private String nombre;
    private String experienciaLaboral;
    private String habilidades;
    private String educacion;

    // Constructor vacío
    public Perfil() {}

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getExperienciaLaboral() {
        return experienciaLaboral;
    }

    public void setExperienciaLaboral(String experienciaLaboral) {
        this.experienciaLaboral = experienciaLaboral;
    }

    public String getHabilidades() {
        return habilidades;
    }

    public void setHabilidades(String habilidades) {
        this.habilidades = habilidades;
    }

    public String getEducacion() {
        return educacion;
    }

    public void setEducacion(String educacion) {
        this.educacion = educacion;
    }
}
