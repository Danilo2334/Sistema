package com.example.api.repository;

import com.example.api.model.Publicacion;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PublicacionRepository extends MongoRepository<Publicacion, String> {}
