package com.example.api.controller;

import com.example.api.model.Publicacion;
import com.example.api.repository.PublicacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/publicaciones")
public class PublicacionController {

    @Autowired
    private PublicacionRepository publicacionRepository;

    // Crear publicación
    @PostMapping
    public Publicacion crearPublicacion(@RequestBody Publicacion publicacion) {
        return publicacionRepository.save(publicacion);
    }

    // Leer todas las publicaciones
    @GetMapping
    public List<Publicacion> listarPublicaciones() {
        return publicacionRepository.findAll();
    }

    // Actualizar publicación
    @PutMapping("/{id}")
    public Publicacion actualizarPublicacion(@PathVariable String id, @RequestBody Publicacion publicacionActualizada) {
        return publicacionRepository.findById(id).map(publicacion -> {
            publicacion.setTexto(publicacionActualizada.getTexto());
            publicacion.setImagen(publicacionActualizada.getImagen());
            publicacion.setVideo(publicacionActualizada.getVideo());
            return publicacionRepository.save(publicacion);
        }).orElseThrow(() -> new RuntimeException("Publicación no encontrada con el ID: " + id));
    }

    // Eliminar publicación
    @DeleteMapping("/{id}")
    public void eliminarPublicacion(@PathVariable String id) {
        publicacionRepository.deleteById(id);
    }
}
