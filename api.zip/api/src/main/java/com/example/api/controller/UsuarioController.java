package com.example.api.controller;

import com.example.api.model.Usuario;
import com.example.api.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Iniciar sesión
    @PostMapping("/iniciar-sesion")
    public Usuario iniciarSesion(@RequestBody Usuario datos) {
        return usuarioRepository.findByCorreo(datos.getCorreo())
                .filter(usuario -> usuario.getContrasena().equals(datos.getContrasena()))
                .orElseThrow(() -> new RuntimeException("Credenciales incorrectas"));
    }
}
