package com.example.api.controller;

import com.example.api.model.Perfil;
import com.example.api.model.Usuario;
import com.example.api.repository.PerfilRepository;
import com.example.api.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/perfiles")
public class PerfilController {

    @Autowired
    private PerfilRepository perfilRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Crear perfil (crea automáticamente el usuario)
    @PostMapping
    public Perfil crearPerfil(@RequestBody Perfil perfil) {
        Usuario usuario = new Usuario();
        usuario.setCorreo(perfil.getCorreo());
        usuario.setContrasena(perfil.getContrasena());
        usuarioRepository.save(usuario);

        return perfilRepository.save(perfil);
    }

    // Leer perfil
    @GetMapping("/{id}")
    public Perfil obtenerPerfil(@PathVariable String id) {
        return perfilRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Perfil no encontrado con el ID: " + id));
    }

    // Actualizar perfil
    @PutMapping("/{id}")
    public Perfil actualizarPerfil(@PathVariable String id, @RequestBody Perfil perfilActualizado) {
        return perfilRepository.findById(id).map(perfil -> {
            perfil.setNombre(perfilActualizado.getNombre());
            perfil.setExperienciaLaboral(perfilActualizado.getExperienciaLaboral());
            perfil.setHabilidades(perfilActualizado.getHabilidades());
            perfil.setEducacion(perfilActualizado.getEducacion());
            return perfilRepository.save(perfil);
        }).orElseThrow(() -> new RuntimeException("Perfil no encontrado con el ID: " + id));
    }

 // Eliminar perfil (también elimina el usuario relacionado)
    @DeleteMapping("/{id}")
    public void eliminarPerfil(@PathVariable String id) {
        // Buscar el perfil por ID
        Perfil perfil = perfilRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Perfil no encontrado con el ID: " + id));

        // Eliminar el perfil
        perfilRepository.deleteById(id);

        // Eliminar el usuario relacionado (usando el correo del perfil)
        usuarioRepository.findByCorreo(perfil.getCorreo())
                .ifPresent(usuario -> usuarioRepository.delete(usuario));
    }

}
